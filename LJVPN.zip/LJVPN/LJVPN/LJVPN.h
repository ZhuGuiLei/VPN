//
//  LJVPN.h
//  LJVPN
//
//  Created by apple on 2020/1/21.
//  Copyright © 2020 layne. All rights reserved.
//

#import <Foundation/Foundation.h>

#import "NetworkExtesionPrivate.h"

//! Project version number for LJVPN.
FOUNDATION_EXPORT double LJVPNVersionNumber;

//! Project version string for LJVPN.
FOUNDATION_EXPORT const unsigned char LJVPNVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <LJVPN/PublicHeader.h>


